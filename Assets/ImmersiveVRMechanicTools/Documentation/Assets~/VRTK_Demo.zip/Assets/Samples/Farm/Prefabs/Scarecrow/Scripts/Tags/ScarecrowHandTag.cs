﻿namespace VRTK.Examples.Scarecrow.Tags
{
    using UnityEngine;

    public class ScarecrowHandTag : MonoBehaviour
    {
    }
}